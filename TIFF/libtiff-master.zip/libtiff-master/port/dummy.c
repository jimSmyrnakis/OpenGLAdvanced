/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void libport_dummy_function() { return; }
